﻿namespace OOP_PROJE
{
    partial class SalaryCalculatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxSalary = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmExperience = new System.Windows.Forms.ComboBox();
            this.cmbCity = new System.Windows.Forms.ComboBox();
            this.cmbEducation = new System.Windows.Forms.ComboBox();
            this.cmbTitle = new System.Windows.Forms.ComboBox();
            this.cmbLanguage = new System.Windows.Forms.ComboBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMinimized = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblHeader = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAmount18 = new System.Windows.Forms.TextBox();
            this.txtAmount718 = new System.Windows.Forms.TextBox();
            this.txtAmount06 = new System.Windows.Forms.TextBox();
            this.chk18 = new System.Windows.Forms.CheckBox();
            this.chk718 = new System.Windows.Forms.CheckBox();
            this.chk06 = new System.Windows.Forms.CheckBox();
            this.chkEsCalismiyor = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblDisplaySalary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBoxSalary
            // 
            this.txtBoxSalary.Location = new System.Drawing.Point(214, 979);
            this.txtBoxSalary.Margin = new System.Windows.Forms.Padding(5);
            this.txtBoxSalary.Name = "txtBoxSalary";
            this.txtBoxSalary.ReadOnly = true;
            this.txtBoxSalary.Size = new System.Drawing.Size(178, 27);
            this.txtBoxSalary.TabIndex = 28;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Thistle;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Location = new System.Drawing.Point(14, 1066);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(174, 60);
            this.btnUpdate.TabIndex = 27;
            this.btnUpdate.Text = "Save";
            this.btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.Thistle;
            this.btnCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalculate.Location = new System.Drawing.Point(14, 972);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(5);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(192, 60);
            this.btnCalculate.TabIndex = 25;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 590;
            this.label1.Text = "Experience";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(210, 20);
            this.label4.TabIndex = 593;
            this.label4.Text = "Foreign Languages Knowledge";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(114, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 592;
            this.label3.Text = "Higher Education";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(199, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 591;
            this.label2.Text = "City";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(199, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 20);
            this.label5.TabIndex = 594;
            this.label5.Text = "Title";
            // 
            // cmExperience
            // 
            this.cmExperience.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cmExperience.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmExperience.ForeColor = System.Drawing.SystemColors.Control;
            this.cmExperience.FormattingEnabled = true;
            this.cmExperience.Location = new System.Drawing.Point(241, 41);
            this.cmExperience.Name = "cmExperience";
            this.cmExperience.Size = new System.Drawing.Size(250, 28);
            this.cmExperience.TabIndex = 596;
            // 
            // cmbCity
            // 
            this.cmbCity.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cmbCity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCity.ForeColor = System.Drawing.SystemColors.Control;
            this.cmbCity.FormattingEnabled = true;
            this.cmbCity.Location = new System.Drawing.Point(241, 91);
            this.cmbCity.Name = "cmbCity";
            this.cmbCity.Size = new System.Drawing.Size(250, 28);
            this.cmbCity.TabIndex = 597;
            // 
            // cmbEducation
            // 
            this.cmbEducation.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cmbEducation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbEducation.ForeColor = System.Drawing.SystemColors.Control;
            this.cmbEducation.FormattingEnabled = true;
            this.cmbEducation.Location = new System.Drawing.Point(241, 141);
            this.cmbEducation.Name = "cmbEducation";
            this.cmbEducation.Size = new System.Drawing.Size(250, 28);
            this.cmbEducation.TabIndex = 598;
            // 
            // cmbTitle
            // 
            this.cmbTitle.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cmbTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbTitle.ForeColor = System.Drawing.SystemColors.Control;
            this.cmbTitle.FormattingEnabled = true;
            this.cmbTitle.Location = new System.Drawing.Point(241, 191);
            this.cmbTitle.Name = "cmbTitle";
            this.cmbTitle.Size = new System.Drawing.Size(250, 28);
            this.cmbTitle.TabIndex = 599;
            // 
            // cmbLanguage
            // 
            this.cmbLanguage.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cmbLanguage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbLanguage.ForeColor = System.Drawing.SystemColors.Control;
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Location = new System.Drawing.Point(241, 241);
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.Size = new System.Drawing.Size(250, 28);
            this.cmbLanguage.TabIndex = 600;
            // 
            // btnCalc
            // 
            this.btnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalc.Location = new System.Drawing.Point(241, 432);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(110, 40);
            this.btnCalc.TabIndex = 602;
            this.btnCalc.Text = "Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImage = global::PersonalManager.Properties.Resources.icons8_close_48__1_;
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClose.Location = new System.Drawing.Point(570, 0);
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 30);
            this.btnClose.TabIndex = 589;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.MouseLeave += new System.EventHandler(this.btnClose_MouseLeave);
            this.btnClose.MouseHover += new System.EventHandler(this.btnClose_MouseHover);
            // 
            // btnMinimized
            // 
            this.btnMinimized.BackgroundImage = global::PersonalManager.Properties.Resources.icons8_minimize_48;
            this.btnMinimized.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMinimized.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimized.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMinimized.Location = new System.Drawing.Point(540, 0);
            this.btnMinimized.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnMinimized.Name = "btnMinimized";
            this.btnMinimized.Size = new System.Drawing.Size(30, 30);
            this.btnMinimized.TabIndex = 588;
            this.btnMinimized.UseVisualStyleBackColor = true;
            this.btnMinimized.Click += new System.EventHandler(this.btnMinimized_Click);
            this.btnMinimized.MouseLeave += new System.EventHandler(this.btnMinimized_MouseLeave);
            this.btnMinimized.MouseHover += new System.EventHandler(this.btnMinimized_MouseHover);
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = global::PersonalManager.Properties.Resources.icons8_left_48;
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(30, 30);
            this.btnBack.TabIndex = 587;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI Variable Display Semib", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHeader.Location = new System.Drawing.Point(265, 0);
            this.lblHeader.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(101, 26);
            this.lblHeader.TabIndex = 603;
            this.lblHeader.Text = "Calculator";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(402, 322);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 16);
            this.label8.TabIndex = 613;
            this.label8.Text = "Amount:";
            this.label8.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(402, 370);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 16);
            this.label6.TabIndex = 612;
            this.label6.Text = "Amount:";
            this.label6.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(402, 346);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 611;
            this.label7.Text = "Amount:";
            this.label7.Visible = false;
            // 
            // txtAmount18
            // 
            this.txtAmount18.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtAmount18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmount18.ForeColor = System.Drawing.SystemColors.Control;
            this.txtAmount18.Location = new System.Drawing.Point(460, 370);
            this.txtAmount18.Name = "txtAmount18";
            this.txtAmount18.Size = new System.Drawing.Size(31, 20);
            this.txtAmount18.TabIndex = 610;
            this.txtAmount18.Visible = false;
            // 
            // txtAmount718
            // 
            this.txtAmount718.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtAmount718.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmount718.ForeColor = System.Drawing.SystemColors.Control;
            this.txtAmount718.Location = new System.Drawing.Point(460, 343);
            this.txtAmount718.Name = "txtAmount718";
            this.txtAmount718.Size = new System.Drawing.Size(31, 20);
            this.txtAmount718.TabIndex = 609;
            this.txtAmount718.Visible = false;
            // 
            // txtAmount06
            // 
            this.txtAmount06.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtAmount06.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAmount06.ForeColor = System.Drawing.SystemColors.Control;
            this.txtAmount06.Location = new System.Drawing.Point(460, 318);
            this.txtAmount06.Name = "txtAmount06";
            this.txtAmount06.Size = new System.Drawing.Size(31, 20);
            this.txtAmount06.TabIndex = 608;
            this.txtAmount06.Visible = false;
            // 
            // chk18
            // 
            this.chk18.AutoSize = true;
            this.chk18.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chk18.Location = new System.Drawing.Point(241, 369);
            this.chk18.Name = "chk18";
            this.chk18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chk18.Size = new System.Drawing.Size(126, 20);
            this.chk18.TabIndex = 607;
            this.chk18.Text = "Child Between 18+ ";
            this.chk18.UseVisualStyleBackColor = true;
            this.chk18.CheckedChanged += new System.EventHandler(this.chk18_CheckedChanged);
            // 
            // chk718
            // 
            this.chk718.AutoSize = true;
            this.chk718.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chk718.Location = new System.Drawing.Point(241, 343);
            this.chk718.Name = "chk718";
            this.chk718.Size = new System.Drawing.Size(126, 20);
            this.chk718.TabIndex = 606;
            this.chk718.Text = "Child Between 7-18";
            this.chk718.UseVisualStyleBackColor = true;
            this.chk718.CheckedChanged += new System.EventHandler(this.chk718_CheckedChanged);
            // 
            // chk06
            // 
            this.chk06.AutoSize = true;
            this.chk06.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chk06.Location = new System.Drawing.Point(241, 317);
            this.chk06.Name = "chk06";
            this.chk06.Size = new System.Drawing.Size(122, 20);
            this.chk06.TabIndex = 605;
            this.chk06.Text = "Child Between 0-6";
            this.chk06.UseVisualStyleBackColor = true;
            this.chk06.CheckedChanged += new System.EventHandler(this.chk06_CheckedChanged);
            // 
            // chkEsCalismiyor
            // 
            this.chkEsCalismiyor.AutoSize = true;
            this.chkEsCalismiyor.Font = new System.Drawing.Font("Segoe UI Variable Display", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.chkEsCalismiyor.Location = new System.Drawing.Point(241, 291);
            this.chkEsCalismiyor.Name = "chkEsCalismiyor";
            this.chkEsCalismiyor.Size = new System.Drawing.Size(161, 20);
            this.chkEsCalismiyor.TabIndex = 604;
            this.chkEsCalismiyor.Text = "Married and Not Working";
            this.chkEsCalismiyor.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(139, 322);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 20);
            this.label9.TabIndex = 614;
            this.label9.Text = "Family Status:";
            // 
            // lblDisplaySalary
            // 
            this.lblDisplaySalary.AutoSize = true;
            this.lblDisplaySalary.Font = new System.Drawing.Font("Segoe UI Variable Display", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDisplaySalary.Location = new System.Drawing.Point(182, 399);
            this.lblDisplaySalary.Name = "lblDisplaySalary";
            this.lblDisplaySalary.Size = new System.Drawing.Size(50, 20);
            this.lblDisplaySalary.TabIndex = 615;
            this.lblDisplaySalary.Text = "Salary:";
            // 
            // SalaryCalculatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(602, 486);
            this.Controls.Add(this.lblDisplaySalary);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAmount18);
            this.Controls.Add(this.txtAmount718);
            this.Controls.Add(this.txtAmount06);
            this.Controls.Add(this.chk18);
            this.Controls.Add(this.chk718);
            this.Controls.Add(this.chk06);
            this.Controls.Add(this.chkEsCalismiyor);
            this.Controls.Add(this.lblHeader);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.cmbLanguage);
            this.Controls.Add(this.cmbTitle);
            this.Controls.Add(this.cmbEducation);
            this.Controls.Add(this.cmbCity);
            this.Controls.Add(this.cmExperience);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnMinimized);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtBoxSalary);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnCalculate);
            this.Font = new System.Drawing.Font("Segoe UI Variable Display", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "SalaryCalculatorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SalaryCalculator";
            this.Load += new System.EventHandler(this.SalaryCalculatorForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtBoxSalary;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMinimized;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmExperience;
        private System.Windows.Forms.ComboBox cmbCity;
        private System.Windows.Forms.ComboBox cmbEducation;
        private System.Windows.Forms.ComboBox cmbTitle;
        private System.Windows.Forms.ComboBox cmbLanguage;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAmount18;
        private System.Windows.Forms.TextBox txtAmount718;
        private System.Windows.Forms.TextBox txtAmount06;
        private System.Windows.Forms.CheckBox chk18;
        private System.Windows.Forms.CheckBox chk718;
        private System.Windows.Forms.CheckBox chk06;
        private System.Windows.Forms.CheckBox chkEsCalismiyor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblDisplaySalary;
    }
}